/**
 * @file student.c
 * @author Eric Zhou (zhoue16@mcmaster.ca)
 * @brief library of functions to manage students
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to a student
 * 
 * @param student Student to add a grade to
 * @param grade Grade to be added to the student
 */
void add_grade(Student* student, double grade)
{
  //increment number of grades by 1
  student->num_grades++;
  //if student initially has no grades, allocate array for first grade
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  //if student has existing grades, reallocate array for another grade
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  //add grade to array of student's grades
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Finds the average of a student
 * 
 * @param student Student whose average is to be calculated
 * @return double - the student's average
 */
double average(Student* student)
{
  //return 0 if there are no grades
  if (student->num_grades == 0) return 0;

  double total = 0;
  //calculate and return student's average
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief prints a student's information
 * 
 * @param student Student struct to be printed
 */
void print_student(Student* student)
{
  //prints name, id, all grades, and average
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Create a student struct with random name, id, and grades
 * 
 * @param grades Number of grades to generate
 * @return Student* pointer to generated student
 */
Student* generate_random_student(int grades)
{
  //array of random first names
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};
  
  //array of random last names
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  //allocate student to be returned
  Student *new_student = calloc(1, sizeof(Student));

  //assign random first and last name
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  //assign random id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //add random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}