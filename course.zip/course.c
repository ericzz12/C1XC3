/**
 * @file course.c
 * @author Eric Zhou (zhoue16@mcmaster.ca)
 * @brief library of functions to manage courses
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enrolls a student in a course
 * 
 * @param course Course struct for the course to be enrolled in
 * @param student Student struct for the student to be enrolled
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  //if course was empty, allocate array for first student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //if course has existing students, reallocate array for another student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //add student to array of students in the course
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints course information
 * 
 * @param course Course struct to be printed
 */
void print_course(Course* course)
{
  //prints name, course code, total students, and all students in the course
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Finds the student with highest average in a course
 * 
 * @param course Course struct to find top student of
 * @return Student* pointer to the student with the highest average in the course
 */
Student* top_student(Course* course)
{
  //return nothing if course has no students
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  //loops through students to find highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Finds the students who are passing in the course
 * 
 * @param course Course struct to find the passing students of
 * @param total_passing Pointer whose value will be set to the number students passing the course
 * @return Student* array of students passing in the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //finds number of students passing
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //allocate arary for number of students passing
  passing = calloc(count, sizeof(Student));

  int j = 0;
  //loops through students to add passing students to array
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}